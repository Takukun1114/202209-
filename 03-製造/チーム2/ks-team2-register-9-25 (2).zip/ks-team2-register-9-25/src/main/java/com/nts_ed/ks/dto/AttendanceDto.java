package com.nts_ed.ks.dto;

public class AttendanceDto {

}
