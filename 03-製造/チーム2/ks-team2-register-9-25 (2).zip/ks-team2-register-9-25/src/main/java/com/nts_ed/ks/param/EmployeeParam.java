package com.nts_ed.ks.param;

import lombok.Data;

@Data
public class EmployeeParam {
	private String id;
	private String name;

	private String dept_id;

}
