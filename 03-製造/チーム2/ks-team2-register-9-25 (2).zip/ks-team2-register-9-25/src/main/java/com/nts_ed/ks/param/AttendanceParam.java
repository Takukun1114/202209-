package com.nts_ed.ks.param;

import lombok.Data;

@Data
public class AttendanceParam {
	
	private String attendance_date;
	
	private String startTime;
	private String endTime;
	private double restHours;
	private double overtimeHours;
	private double absenceHours;
	
	private String workingId;
	private String workingDetails;
	
	
	private String updateUser;
	private int flowStatusId;
	
	
	
	
}
