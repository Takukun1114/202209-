package com.nts_ed.ks.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.nts_ed.ks.entity.Attendance;

@Repository
public interface AttendanceRepository extends JpaRepository<Attendance, String> {
	
//	@Query(value = "SELECT *"
//			+ "FROM t_attendance"
//			+ ""
//			+ " WHERE t_employee.employee_id = :employee_id"
//			
//			
//			)
	
	
}
