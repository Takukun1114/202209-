package com.nts_ed.ks.dto;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nts_ed.ks.repository.EmployeeRepository;

@Service
public class EmployeeService {
	
	@Autowired
	private EmployeeRepository employeeRepository;
	
	
	
//	public List<Employee>find(String employeeId,String employeeName,String deptId){
//			
//		List<Employee>employees;
//		employees = employeeRepository.find(employeeId,employeeName,deptId);
//			
//		return employees;	
//		
//		} 
//		
		
}
