package com.nts_ed.ks.entity;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.validation.constraints.Size;

import lombok.Data;

@Data
@Entity(name = "t_employee")
public class Employee {

	@Id
	@Size(max = 10)
	private String employee_id;
	@Size(max = 100)
	private String employee_name;
	@Size(max = 8)
	private String password;
	
	@ManyToOne
	@JoinColumn(name = "dept_id")
	private Department department;
	
	
	private int del_flg;
	private Date create_date;
	@Size(max = 10)
	private String create_user;
	private Date update_date;
	@Size(max = 10)
	private String update_user;
	@Size(max = 50)
	private String employee_email;
	
	
	
//	@OneToMany(mappedBy = "employee",cascade = CascadeType.ALL)
//	private List<Attendance>attendances;
	
	
}
