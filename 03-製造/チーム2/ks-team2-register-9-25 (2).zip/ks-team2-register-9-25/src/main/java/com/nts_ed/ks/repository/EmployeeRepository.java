package com.nts_ed.ks.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.nts_ed.ks.entity.Employee;

// This will be AUTO IMPLEMENTED by Spring into a Bean called userRepository
// CRUD refers Create, Read, Update, Delete
// Hibernate


@Repository
public interface EmployeeRepository extends JpaRepository<Employee, String> {
	
//	@Query(value = " SELECT *"
//				 + " FROM t_employee"
//				 + " LEFT JOIN m_dept ON t_employee.dept_id = m_dept.dept_id"
//				 + " WHERE t_employee.employee_id = :employee_id"
//				 + " AND t_employee.del_flg = 0"
//				 ,nativeQuery = true)
//	List<Employee> find(String employeeId, String employeeName, String deptId);
	
	
	
	
//	@Query(value = "SELECT * FROM t_employee WHERE employee_id = :employee_id AND password = :password", nativeQuery = true)
//	List<Employee>EmployeeInfo(@Param("employee_id")String id,@Param("password")String pass
//			,@Param("dept_id")String dept_id);
}	
