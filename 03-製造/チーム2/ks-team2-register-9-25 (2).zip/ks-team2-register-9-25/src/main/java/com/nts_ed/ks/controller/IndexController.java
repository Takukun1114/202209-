package com.nts_ed.ks.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.nts_ed.ks.dto.EmployeeService;
import com.nts_ed.ks.entity.Attendance;
import com.nts_ed.ks.repository.AttendanceRepository;
import com.nts_ed.ks.repository.EmployeeRepository;

@Controller
@RequestMapping(path = "/")
public class IndexController {
	
	@Autowired
	private HttpSession session;
	
	
	
	@Autowired
	private EmployeeRepository employeeRepository;
	
	@Autowired
	private AttendanceRepository attendancerepository;
	
	
	@Autowired
	private EmployeeService employeeService;
	
	
	@GetMapping(path = "/")
	public String getLogin() {
		//login.htmlに画面遷移
		return "Login";
	}

	
	
	
//	@PostMapping(path = "/login")
//	public String index(@RequestParam LoginParam param,Model model) {
//		List<Employee>LoginEmployees = employeeRepository.LoginEmployees(param.getId(), param.getPass());
//		
//		model.addAttribute("LoginEmployee",LoginEmployees);
//		
//		
//		// 項目の初期化が書く必要になります。
//		return "AttendanceRegister";
//	}
	
//	
//	@PostMapping(path = "/login/attendance")
//	public String postLogin(@RequestParam ("Attendance")
//	String employeeId,String employeeName,String deptId,Model model) {
//		
//		List<Employee>employeeInfo = employeeRepository.find(employeeId,employeeName,deptId); 
//		
//		
//		model.addAttribute("employee",employeeInfo);
//		session.setAttribute("employee", employeeInfo);
//		
//		
//		return "AttendanceRegister";
//	}
	
	
	
	
//	@GetMapping(path = "/login/attendanceList")
//	public String 
//	
//	
//
//	@PostMapping(path = "/login/attendanceList")
//	public @ResponseBody List<Employee> test(@Validated @ModelAttribute LoginParam param) {
//		// 社員のチェックを行います
//		return "AttendanceDetails";
//	}
//	
//	
//	
//	@GetMapping(path = "/login/attendanceList/attendanceDetails")
//	
//	public String 
//	
//	
//	
//	@PostMapping(path = "/login/attendanceList/attendanceDetails")
//	public @ResponseBody List<Employee> test(@Validated @ModelAttribute LoginParam param) {
//		// 社員のチェックを行います
//		return "AttendanceDetails";
//	}
	
	
	
	@GetMapping(path = "/register")//login/attendanceList/attendanceDetails/
	public ModelAndView attendanceRegister(@ModelAttribute Attendance attendance
			,ModelAndView mav) {
		
		
		mav.addObject("Attendance",attendance);
	
		
		mav.setViewName("AttendanceRegister");
		
	return mav;
	
	}
	
	
	@PostMapping(path = "/register")///login/attendanceList/attendanceDetails
	public ModelAndView attendanceRegisterPost(@ModelAttribute @Validated Attendance attendance
			,BindingResult result,ModelAndView mav) {
		
		if (result.hasErrors()) {
			
			mav.addObject(result);
			
			mav.setViewName("AttendanceRegister");
		
		return mav;
	}
	
	attendancerepository.saveAndFlush(attendance);
	
	mav = new ModelAndView("redirect:/register");
	
	
	return mav;
	
	}
	
	



}
