package com.nts_ed.ks.entity;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name =  "t_attendance")
public class Attendance {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long record_id;
	
	private String attendance_date;
	
	private String start_time;
	private String end_time;
	private double rest_hours;
	private double working_hours;
	
	private double overtime_hours;
	private double absence_hours;
	
	@ManyToOne
	@JoinColumn(name = "working_id")
	private WorkingStatus workingStatus;
	
	
	private String working_details;
	
	
	private Date create_date;
	private String create_user;
	private Date update_date;
	private String update_user;
	
	private int flow_status_id;

}
