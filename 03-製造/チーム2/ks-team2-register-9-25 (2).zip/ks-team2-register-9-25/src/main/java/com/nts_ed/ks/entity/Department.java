package com.nts_ed.ks.entity;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.validation.constraints.Size;

import lombok.Data;

@Data
@Entity(name = "m_dept")
public class Department {
	
	@Id
	private String dept_id;
	private String dept_name;
	
	private int del_flg;
	private Date create_date;
	
	@Size(max = 10)
	private String create_user;
	private Date update_date;
	
	@Size(max = 10)
	private String update_user;

//	@OneToMany
//	(mappedBy = "department",cascade = CascadeType.ALL)
//	private List<Employee>employees;

}
