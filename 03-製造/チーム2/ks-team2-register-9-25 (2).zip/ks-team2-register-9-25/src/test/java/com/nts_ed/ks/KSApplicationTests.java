package com.nts_ed.ks;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KSApplicationTests {

	@Test
	void contextLoads() {
	}

}
